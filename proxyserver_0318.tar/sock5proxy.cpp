
#include "sock5proxy.h"
#include "ThreadPool.h"
std::deque<CCmdInfo> cmdqueue;
std::mutex mu;
std::condition_variable cond;
using std::vector;

std::deque<CCmdInfo> resetq;
std::mutex resetmu;
std::condition_variable resetcond;

extern char *arg_username;
extern char *arg_password;
extern FILE *log_file;
extern int auth_type;

extern CLog nicresetlog;

extern vector <StNicInfo> vecstr;
// extern pthread_mutex_t idxlock;

int extern GetModemInfo(CLog &log);

extern pthread_mutex_t niclock;

int resetnicinfo(CLog &log, int idx, string strnicinfo)
{
	FILE *fp;
	char buf[128];
	// idx = 108;
	// string strnicinfo = "wwan3";
	snprintf(buf, sizeof(buf), "mmcli -m %d --command=\"AT+CFUN=0\"", idx);
	int ret = system(buf);
	logDebug(log, "resetnicinfo: buf=%s ret=%d", buf, ret);
	if (0 != ret)
	{
		logError(log, "resetnicinfo: Excute shell cmd[%s] failed, return:%d.", buf, ret>>8);
		snprintf(buf, sizeof(buf), "mmcli -m %d --command=AT+CRESET", idx);
		// logDebug(log, "executethd: cmd=%s", buf);
		ret = system(buf);
		logDebug(log, "resetnicinfo: cmd=%s ret=%d", buf, ret);
		if (0 != ret)
		{
			logError(log, "Excute shell cmd[%s] failed, return:%d.", buf, ret>>8);
			// return 0;
		}

		return -1;
	}

	sleep(3);
	snprintf(buf, sizeof(buf), "mmcli -m %d --command=\"AT+CFUN=1\"", idx);
	ret = system(buf);
	logDebug(log, "resetnicinfo: buf=%s ret=%d", buf, ret);
	if (0 != ret)
	{
		logError(log, "resetnicinfo: Excute shell cmd[%s] failed, return:%d.", buf, ret>>8);
		snprintf(buf, sizeof(buf), "mmcli -m %d --command=AT+CRESET", idx);
		// logDebug(log, "executethd: cmd=%s", buf);
		ret = system(buf);
		logDebug(log, "resetnicinfo: cmd=%s ret=%d", buf, ret);
		if (0 != ret)
		{
			logError(log, "resetnicinfo: Excute shell cmd[%s] failed, return:%d.", buf, ret>>8);
			// return 0;
		}
		return -1;
	}
	int sleepcnt = 0;
	int maxcnt = 7;
	// sleep(2);
	while (1)
	{
		char cmd[128];
		snprintf(cmd, sizeof(cmd), "ifconfig %s|grep inet|grep -v 127.0.0.1|grep -v inet6|awk '{print $2}'|tr -d \"addr:\"",
			strnicinfo.c_str());
		if ((fp = popen(cmd, "r")) == NULL)
		{
			logError(log, "popen fail\n");
			sleepcnt++;
			sleep(1);
			continue;
			// return -1;
		}

		// logDebug(log, "resetnicinfo: cmd=%s", cmd);

		if (fgets(buf, 128, fp) != NULL)
		{
			logDebug(log, "resetnicinfo: %s network restart succeed buf=%s cmd=%s", strnicinfo.c_str(), buf, cmd);
			pclose(fp);
			break;
		}

		pclose(fp);
		// logDebug(log, "sleep 1 sec and try again");
		if (sleepcnt >= maxcnt)
		{
			// logDebug(log, "will resset %d", idx);

			snprintf(buf, sizeof(buf), "mmcli -m %d --command=AT+CRESET", idx);
			// logDebug(log, "executethd: cmd=%s", buf);
			ret = system(buf);
			logDebug(log, "resetnicinfo: cmd=%s ret=%d", buf, ret);
			if (0 != ret)
			{
				logError(log, "Excute shell cmd[%s] failed, return:%d.", buf, ret>>8);
				// return 0;
			}
			break;
		}

		sleepcnt++;
		sleep(1);
	}

	return 0;
}

int socks_invitation(int fd, int *version, CLog &log)
// int socks_invitation(int fd, int *version)
{
	char init[2];
	int nread = readn(fd, (void *)init, ARRAY_SIZE(init));
	if (nread == 2 && init[0] != VERSION5 && init[0] != VERSION4) 
	{
        logDebug(log, "They send us %hhX %hhX", init[0], init[1]);
		logDebug(log, "Incompatible version!");
		// app_thread_exit(0, fd);
        close(fd);
		return -1;
	}

	// log_message("socks_invitation nread=%d", nread);

	// log_message("Initial %hhX %hhX", init[0], init[1]);
	*version = init[0];
	return init[1];
}

char *socks5_auth_get_user(int fd)
{
	unsigned char size;
	readn(fd, (void *)&size, sizeof(size));

	char *user = (char *)malloc(sizeof(char) * size + 1);
	readn(fd, (void *)user, (int)size);
	user[size] = 0;

	return user;
}

char *socks5_auth_get_pass(int fd)
{
	unsigned char size;
	readn(fd, (void *)&size, sizeof(size));

	char *pass = (char *)malloc(sizeof(char) * size + 1);
	readn(fd, (void *)pass, (int)size);
	pass[size] = 0;

	return pass;
}

int socks5_auth_userpass(int fd)
{
	char answer[2] = { (char)VERSION5, (char)USERPASS };
	writen(fd, (void *)answer, ARRAY_SIZE(answer));
	char resp;
	readn(fd, (void *)&resp, sizeof(resp));
	// log_message("auth %hhX", resp);
	char *username = socks5_auth_get_user(fd);
	char *password = socks5_auth_get_pass(fd);
	// log_message("l: %s p: %s", username, password);
	if (strcmp(arg_username, username) == 0
	    && strcmp(arg_password, password) == 0) 
	{
		char answer[2] = { AUTH_VERSION, AUTH_OK };
		writen(fd, (void *)answer, ARRAY_SIZE(answer));
		free(username);
		free(password);
		return 0;
	} 
	else 
	{
		char answer[2] = { (char)AUTH_VERSION, (char)AUTH_FAIL };
		writen(fd, (void *)answer, ARRAY_SIZE(answer));
		free(username);
		free(password);
		return 1;
	}
}

int socks5_auth_noauth(int fd)
{
	char answer[2] = { (char)VERSION5, (char)NOAUTH };
	writen(fd, (void *)answer, ARRAY_SIZE(answer));
	return 0;
}

void socks5_auth_notsupported(int fd)
{
	char answer[2] = { (char)VERSION5, (char)NOMETHOD };
	writen(fd, (void *)answer, ARRAY_SIZE(answer));
}

int socks5_auth(int fd, int methods_count)
{
	int supported = 0;
	int num = methods_count;
	// log_message("methods_count=%d", methods_count);
	for (int i = 0; i < num; i++) 
	{
		char type;
		readn(fd, (void *)&type, 1);
		// log_message("Method AUTH %hhX auth_type=%d", type, auth_type);
		if (type == auth_type) 
		{
			supported = 1;
			break;
		}
	}
	if (supported == 0) 
	{
		socks5_auth_notsupported(fd);
		// app_thread_exit(1, fd);
        close(fd);
		return -1;
	}
	int ret = 0;
	switch (auth_type) 
	{
	case NOAUTH:
		ret = socks5_auth_noauth(fd);
		break;
	case USERPASS:
		ret = socks5_auth_userpass(fd);
		break;
	}

	if (ret == 0) 
	{
		return 0;
	} 
	else 
	{
		// app_thread_exit(1, fd);
        close(fd);
		return -1;
	}

	return 0;
}

int socks5_command(int fd)
{
	// log_message("socks5_command fd=%d", fd);
	char command[4];
	readn(fd, (void *)command, ARRAY_SIZE(command));
	// log_message("Command %hhX %hhX %hhX %hhX", command[0], command[1],
	// 	    command[2], command[3]);

	// log_message("Command %d %d %d %d", command[0], command[1],
		    // command[2], command[3]);

	return command[3];
}

unsigned short int socks_read_port(int fd)
{
	unsigned short int p;
	readn(fd, (void *)&p, sizeof(p));
	// log_message("Port %hu", ntohs(p));
	return p;
}

char *socks_ip_read(int fd)
{
	char *ip = (char *)malloc(sizeof(char) * IPSIZE);
	readn(fd, (void *)ip, IPSIZE);
	// log_message("IP %hhu.%hhu.%hhu.%hhu", ip[0], ip[1], ip[2], ip[3]);
	return ip;
}

void socks5_ip_send_response(int fd, char *ip, unsigned short int port)
{
	char response[4] = { VERSION5, OK, RESERVED, IP };
	writen(fd, (void *)response, ARRAY_SIZE(response));
	writen(fd, (void *)ip, IPSIZE);
	writen(fd, (void *)&port, sizeof(port));
}

char *socks5_domain_read(int fd, unsigned char *size)
{
	unsigned char s;
	readn(fd, (void *)&s, sizeof(s));
	char *address = (char *)malloc((sizeof(char) * s) + 1);
	readn(fd, (void *)address, (int)s);
	address[s] = 0;
	// log_message("Address %s", address);
	*size = s;
	return address;
}

void socks5_domain_send_response(int fd, char *domain, unsigned char size,
				 unsigned short int port)
{
	char response[4] = { VERSION5, OK, RESERVED, DOMAIN };
	writen(fd, (void *)response, ARRAY_SIZE(response));
	writen(fd, (void *)&size, sizeof(size));
	writen(fd, (void *)domain, size * sizeof(char));
	writen(fd, (void *)&port, sizeof(port));
}

void *reset_nic_process(void *fd)
{
	CLog nicresetlog("nicresetlog");
	if(nicresetlog.init(CLOG_DEBUG) < 0)
	{
		fprintf(stderr, "init log faild.\n");
	}
	logDebug(nicresetlog, "func begin");
	StNicInfo *info = (StNicInfo *)fd;
	int idx = -1;
	for (auto data:vecstr)
	{
		if (data.strnic == info->strnic)
		{
			idx = data.idx;
			break;
		}
	}

	if (idx < 0)
	{
		return NULL;
	}

	resetnicinfo(nicresetlog, idx, info->strnic);

	pthread_mutex_lock(&niclock);
	GetModemInfo(nicresetlog);
	pthread_mutex_unlock(&niclock);
	
	delete fd;
	return NULL;
}

void resetnic(CLog &log)
{
	bool isreset = false;
	for (auto &data:vecstr)
	{
		FILE *fp = NULL;
		char buf[256];
		char cmd[256];

		snprintf(cmd, sizeof(cmd), "ifconfig %s|grep inet|grep -v 127.0.0.1|grep -v inet6|awk '{print $2}'|tr -d \"addr:\"",
		data.strnic.c_str());
		if ((fp = popen(cmd, "r")) == NULL)
		{
			logDebug(log, "popen fail\n");
			continue;
			// return -1;
		}

		// logDebug(log, "resetnicinfo: cmd=%s", cmd);
		
		if (fgets(buf, 256, fp) == NULL)
		{
			resetnicinfo(log, data.idx, data.strnic);
			pthread_mutex_lock(&niclock);
			GetModemInfo(log);
			pthread_mutex_unlock(&niclock);
			break;
		}		
	}
}

void checknicinfo()
{
	char buf[256];
	char cmd[256];
	CLog log("checknicinfo");
	if(log.init(CLOG_DEBUG) < 0)
	{
		fprintf(stderr, "init log faild.\n");
	}

	int second = 120;

	while (1)
	{
		resetnic(log);
		logDebug(log, "timeout");
		sleep(second);

		// logDebug(log, "%s network will reset use at+creset command", strnic.c_str());

		// logDebug(log, "executethd: %s will restart network", strnic.c_str());
	}
    
}

void executethd()
{
	char buf[256];
	char cmd[256];
	CLog log("executethd");
	if(log.init(CLOG_DEBUG) < 0)
	{
		fprintf(stderr, "init log faild.\n");
	}

	int second = 120;

	while (1)
	{
		std::unique_lock<std::mutex> locker(mu);
		while(cmdqueue.empty())
		{
			if (std::cv_status::timeout == cond.wait_for(locker, std::chrono::seconds(second)))
			{
				// return false;
				resetnic(log);
				logDebug(log, "timeout");
				continue;
			}
			// cond.wait(locker); // Unlock mu and wait to be notified
		}
			

		string strnic = cmdqueue.front().strnic;
		// int idx = cmdqueue.front().idx;
		// logDebug(log, "nic=%s idx=%d have data to process", strnic, idx);
		cmdqueue.pop_front();

		locker.unlock();
		
		int idx = -1;
		for (auto data:vecstr)
		{
			if (data.strnic == strnic)
			{
				idx = data.idx;
				break;
			}
		}

		if (idx < 0)
		{
			continue;
		}

		resetnicinfo(log, idx, strnic);

		pthread_mutex_lock(&niclock);
		GetModemInfo(log);
		pthread_mutex_unlock(&niclock);

		// logDebug(log, "%s network will reset use at+creset command", strnic.c_str());

		// logDebug(log, "executethd: %s will restart network", strnic.c_str());
	}
    
}

int readn(int fd, void *buf, int n)
{
	int nread, left = n;
	while (left > 0) 
	{
		if ((nread = read(fd, buf, left)) == -1) 
		{
			if (errno == EINTR || errno == EAGAIN) 
			{
				continue;
			}
		} 
		else 
		{
			if (nread == 0) 
			{
				return 0;
			} 
			else 
			{
				left -= nread;
				buf += nread;
			}
		}
	}
	return n;
}

int writen(int fd, void *buf, int n)
{
	int nwrite, left = n;
	while (left > 0) {
		if ((nwrite = write(fd, buf, left)) == -1) 
		{
			if (errno == EINTR || errno == EAGAIN) 
			{
				continue;
			}
		} 
		else 
		{
			if (nwrite == n) 
			{
				return 0;
			} 
			else 
			{
				left -= nwrite;
				buf += nwrite;
			}
		}
	}
	return n;
}



bool StNicInfo::isavalable()
{
	if (true == iscanused && currentcnt < maxsendcnt)
	{
		currentcnt++;
		return true;
	}


	iscanused = false;
	currentcnt = 0;
	return false;
}

StNicInfo::StNicInfo(string nicdata, int index)
{
	strnic = nicdata;
	iscanused = false;
	currentcnt = 0;
	idx = index;
}

void StNicInfo::enable()
{
	iscanused = true;
	currentcnt = 0;
}



