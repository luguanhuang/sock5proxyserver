#ifndef SOCK5_PROXY_H
#define SOCK5_PROXY_H

#include <deque>
#include <mutex>
#include <string>

#include <sys/types.h>
#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/fcntl.h>
#include <sys/stat.h>
#include <netdb.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <pthread.h>
#include <netinet/in.h>
#include <net/if.h>
#include <linux/sockios.h>
#include <sys/ioctl.h>
#include <algorithm> 
#include <vector>
#include <map>
#include <string>
#include <iostream>
#include <queue>
#include "log_lib_cplus.h" 
#include <sstream>
#include <thread>

#define BUFSIZE 65536
#define IPSIZE 4
#define ARRAY_SIZE(x) (sizeof(x) / sizeof(x[0]))
#define ARRAY_INIT    {0}

#include <condition_variable>
using std::condition_variable;
using std::mutex;
using std::string;
using std::vector;
using std::map;

const int maxsendcnt = 100;

class StSockInfo
{
public:
	int sock;
	int seq;
	CLog *log;
};

class StNicInfo 
{
public:
	StNicInfo(string nicdata, int index);
	StNicInfo(){};
	void enable();
	bool isavalable();
	// StNicInfo *operator =(const StNicInfo &rhs);

	string strnic;
	bool iscanused;
	int currentcnt;
	int idx;
	CLog *log;
};

enum socks 
{
	RESERVED = 0x00,
	VERSION4 = 0x04,
	VERSION5 = 0x05
};

enum socks_auth_methods 
{
	NOAUTH = 0x00,
	USERPASS = 0x02,
	NOMETHOD = 0xff
};

enum socks_auth_userpass 
{
	AUTH_OK = 0x00,
	AUTH_VERSION = 0x01,
	AUTH_FAIL = 0xff
};

enum socks_command 
{
	CONNECT = 0x01
};

enum socks_command_type 
{
	IP = 0x01,
	DOMAIN = 0x03
};

enum socks_status 
{
	OK = 0x00,
	FAILED = 0x05
};

enum cmd_id
{
	RESTART_NETWORK = 0x00,
	IFUP_NIC = 0x01
};

int socks_invitation(int fd, int *version, CLog &log);
char *socks5_auth_get_user(int fd);
char *socks5_auth_get_pass(int fd);
int socks5_auth_userpass(int fd);
int socks5_auth_noauth(int fd);
void socks5_auth_notsupported(int fd);
int socks5_auth(int fd, int methods_count);
int socks5_command(int fd);
unsigned short int socks_read_port(int fd);
char *socks_ip_read(int fd);
void socks5_ip_send_response(int fd, char *ip, unsigned short int port);

char *socks5_domain_read(int fd, unsigned char *size);

void socks5_domain_send_response(int fd, char *domain, unsigned char size,
				 unsigned short int port);

void *reset_nic_process(void *fd);

void checknicinfo();

void resetnic();

void log_message(const char *message, ...);
void executethd();

int readn(int fd, void *buf, int n);
int writen(int fd, void *buf, int n);
class CCmdInfo
{
public:
    cmd_id id;
    int idx;
    string strnic;     
};

class CSock5Proxy
{
    public:
};

#endif