pkill -9 proxyserver
ulimit -c 10240
./proxyserver  -n 10800 &
