#define _GNU_SOURCE

#include "ThreadPool.h"
#include "sock5proxy.h"
#include <algorithm>
// using namespace std;
#include <sys/time.h>
ThreadPool resetnicpool(35);  // 弄4个线程

using std::queue;
using std::map;
using std::string;
using std::vector;

extern std::deque<CCmdInfo> resetq;
extern std::mutex resetmu;
extern std::condition_variable resetcond;

extern std::deque<CCmdInfo> cmdqueue;
extern std::mutex mu;
extern std::condition_variable cond;


unsigned short int port = 1080;
int daemon_mode = 0;
int auth_type;
char *arg_username;
char *arg_password;
FILE *log_file;
int curidx = 0;

pthread_mutex_t niclock;

#include "log_lib_cplus.h" 

vector <StNicInfo> vecstr;

string getnic()
{
	pthread_mutex_lock(&niclock);

	int tmpidx = curidx % vecstr.size();
	if (vecstr[tmpidx].isavalable())
	{
		pthread_mutex_unlock(&niclock);
		// curidx++;
		return vecstr[tmpidx].strnic;
	}
	else
	{
		StNicInfo *stNicInfo = new StNicInfo(vecstr[tmpidx].strnic, vecstr[tmpidx].idx);
		// StNicInfo *stNicInfo = new StNicInfo(data.strnic, data.idx);
		resetnicpool.addTask(reset_nic_process, stNicInfo);

		// CCmdInfo info;
		// info.strnic = vecstr[tmpidx].strnic;
		// info.idx = vecstr[tmpidx].idx;
		// std::unique_lock<std::mutex> locker(mu);
		// cmdqueue.push_back(info);
		// locker.unlock();
		// cond.notify_one();  // Notify one waiting thread, if there is one.
	}

	int cnt = 0;
	while (1)
	{
		if (vecstr[tmpidx].isavalable())
		{
			break;
		}
		else if (cnt > vecstr.size())
		{
			pthread_mutex_unlock(&niclock);
			return "";
		}

		tmpidx = ++tmpidx % vecstr.size();
		cnt++;
	}

	curidx = tmpidx;
	// curidx++;
	// curidx = ++curidx % vecstr.size();
	pthread_mutex_unlock(&niclock);

	return vecstr[tmpidx].strnic;
}

bool isconnected(int sockfd, fd_set *rd, fd_set *wr)
{
    if (!FD_ISSET(sockfd, rd) && !FD_ISSET(sockfd, wr)) {
    return false;
    }
    int err;
    socklen_t len = sizeof(err);
    if (getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &err, &len) < 0) {
    return false;
    }
    errno = err;        /* in case we're not connected */
    return err == 0;
}

int connect_timeout(int sockfd, const struct sockaddr *addr,
                    socklen_t addrlen, struct timeval *timeout) 
{
    int flags = fcntl( sockfd, F_GETFL, 0 );
    if (flags == -1) {
    return -1;
    }
    if (fcntl( sockfd, F_SETFL, flags | O_NONBLOCK ) < 0) {
    return -1;
    }
    int status = connect(sockfd, addr, addrlen);
    if (status == -1 and errno != EINPROGRESS) {
    return -1;
    }
    if (status == 0) {
    if (fcntl(sockfd, F_SETFL, flags) <  0) {
        return -1;
    }
    return 1;
    }
    fd_set read_events;
    fd_set write_events;
    FD_ZERO(&read_events);
    FD_SET(sockfd, &read_events);
    write_events = read_events;
    int rc = select(sockfd + 1, &read_events, &write_events, nullptr, timeout );
    if (rc < 0) {
    return -1;
    } else if (rc == 0) {
    return 0;
    }
    if (!isconnected(sockfd, &read_events, &write_events) )
    {
    return -1;
    }
    if ( fcntl( sockfd, F_SETFL, flags ) < 0 ) {
    return -1;
    }
    return 1;
}

int app_connect(int type, void *buf, unsigned short int portnum, CLog &log)
{
	int fd;
	struct sockaddr_in remote;
	char address[16];

	memset(address, 0, ARRAY_SIZE(address));

	if (type == IP) 
	{
		char *ip = (char *)buf;
		snprintf(address, ARRAY_SIZE(address), "%hhu.%hhu.%hhu.%hhu",
			 ip[0], ip[1], ip[2], ip[3]);
		memset(&remote, 0, sizeof(remote));
		remote.sin_family = AF_INET;
		remote.sin_addr.s_addr = inet_addr(address);
		remote.sin_port = htons(portnum);

		fd = socket(AF_INET, SOCK_STREAM, 0);

		struct ifreq interface;
		string str = getnic();
		if (str == "")
		{
			logDebug(log, "dont have nic");
			close(fd);
			return -1;
		}

		logDebug(log, "get nic name =%s connect ip=%s portnum=%d", str.c_str(), address, portnum);
		// cout << "get nic name =" << str << " connect ip=" << address << " portnum=" << portnum <<  endl;
		snprintf(interface.ifr_ifrn.ifrn_name, sizeof(interface.ifr_ifrn.ifrn_name),
			"%s", str.c_str());
    	// strncpy(interface.ifr_ifrn.ifrn_name, str.c_str(), str.size());
		if (setsockopt(fd, SOL_SOCKET, SO_BINDTODEVICE, (char *)&interface, sizeof(interface))  < 0) 
		{
			perror("SO_BINDTODEVICE failed 1");
		}

		// log_message("connect() in before connect");
		// if (connect(fd, (struct sockaddr *)&remote, sizeof(remote)) < 0) 
		timeval tm;
		tm.tv_sec = 3;
		tm.tv_usec = 0;
		if (connect_timeout(fd, (struct sockaddr *)&remote, sizeof(remote), &tm) < 0) 
		{
			logDebug(log, "connect() in app_connect ip=%s port=%d", address, portnum);
			close(fd);
			return -1;
		}
		
		return fd;
	} 
	else if (type == DOMAIN) 
	{
		char portaddr[6];
		struct addrinfo *res;
		snprintf(portaddr, ARRAY_SIZE(portaddr), "%d", portnum);
		
		int ret = getaddrinfo((char *)buf, portaddr, NULL, &res);
		if (ret == EAI_NODATA) 
		{
			return -1;
		} 
		else if (ret == 0) 
		{
			struct addrinfo *r;
			for (r = res; r != NULL; r = r->ai_next) 
			{
				fd = socket(r->ai_family, r->ai_socktype,
					    r->ai_protocol);
                if (fd == -1) 
				{
                    continue;
                }
				ret = connect(fd, r->ai_addr, r->ai_addrlen);
				if (ret == 0) 
				{
					freeaddrinfo(res);
					return fd;
                } 
				else 
				{
                    close(fd);
                }
			}
		}
		freeaddrinfo(res);
		return -1;
	}

    return -1;
}



int socks4_is_4a(char *ip)
{
	return (ip[0] == 0 && ip[1] == 0 && ip[2] == 0 && ip[3] != 0);
}

int socks4_read_nstring(int fd, char *buf, int size)
{
	char sym = 0;
	int nread = 0;
	int i = 0;

	while (i < size) 
	{
		nread = recv(fd, &sym, sizeof(char), 0);

		if (nread <= 0) 
		{
			break;
		} 
		else 
		{
			buf[i] = sym;
			i++;
		}

		if (sym == 0) 
		{
			break;
		}
	}

	return i;
}

void socks4_send_response(int fd, int status)
{
	char resp[8] = {0x00, (char)status, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
	writen(fd, (void *)resp, ARRAY_SIZE(resp));
}

void app_socket_pipe(int fd0, int fd1, CLog &log, int seq)
{
	int maxfd, ret;
	fd_set rd_set;
	size_t nread;
	char buffer_r[BUFSIZE];	
	struct timeval start;
    struct timeval end;
	float time_use=0;

	timeval tm;
	tm.tv_sec = 5;
	maxfd = (fd0 > fd1) ? fd0 : fd1;
	while (1) 
	{
		FD_ZERO(&rd_set);
		FD_SET(fd0, &rd_set);
		FD_SET(fd1, &rd_set);
		ret = select(maxfd + 1, &rd_set, NULL, NULL, &tm);
		if (ret <= 0)
			break;

		if (FD_ISSET(fd0, &rd_set)) 
		{
			gettimeofday(&start,NULL); //gettimeofday(&start,&tz);结果一样
			nread = recv(fd0, buffer_r, BUFSIZE, 0);
			if (nread <= 0)
			{
				// cout << "app_socket_pipe: recv=" << nread << endl; 
				break;
			}

			int ret = send(fd1, (const void *)buffer_r, nread, 0);
			if (ret <=0)
			{
				// cout << "app_socket_pipe: recv11=" << nread << endl; 
				break;
			}
			gettimeofday(&end,NULL); //gettimeofday(&start,&tz);结果一样
			time_use=(end.tv_sec-start.tv_sec)*1000+(end.tv_usec-start.tv_usec)/1000;//微秒
   			logDebug(log, "recv from server  need  %.6f ms seq=%d\n",time_use, seq);
		}

		if (FD_ISSET(fd1, &rd_set)) 
		{
			gettimeofday(&start,NULL); //gettimeofday(&start,&tz);结果一样
			nread = recv(fd1, buffer_r, BUFSIZE, 0);
			if (nread <= 0)
			{
				// cout << "app_socket_pipe: recv22=" << nread << endl; 
				
				break;
			}
				
			int ret = send(fd0, (const void *)buffer_r, nread, 0);
			if (ret <=0)
			{
				
				// cout << "app_socket_pipe: recv33=" << nread << endl; 
				break;
			}
			gettimeofday(&end,NULL); //gettimeofday(&start,&tz);结果一样
			time_use=(end.tv_sec-start.tv_sec)*1000+(end.tv_usec-start.tv_usec)/1000;//微秒
   			logDebug(log, "send to client  need  %.6f ms seq=%d\n",time_use, seq);
		}
	}
}

void *app_thread_process(void *fd)
{
	StSockInfo *info = (StSockInfo *)fd;
	int seq = info->seq;
	int net_fd = info->sock;
	int version = 0;
	int inet_fd = -1;
	struct timeval start;
    struct timeval end;
	float time_use=0;
	
	// CLog log("procclientmsg");
	// if(log.init(CLOG_DEBUG) < 0)
	// {
	// 	fprintf(stderr, "init log faild.\n");
	// }

	gettimeofday(&start,NULL); //gettimeofday(&start,&tz);结果一样
	char methods = socks_invitation(net_fd, &version, (*(info->log)));
	if (-1 == methods)
	{
		// close(inet_fd);
		return NULL;
	}

	gettimeofday(&end,NULL);
	time_use=(end.tv_sec-start.tv_sec)*1000+(end.tv_usec-start.tv_usec)/1000;//微秒
    logDebug((*(info->log)), "socks_invitation function need  %.6f ms seq=%d\n",time_use, seq);

	switch (version) {
	case VERSION5: 
	{
			gettimeofday(&start,NULL); //gettimeofday(&start,&tz);结果一样
			if (socks5_auth(net_fd, methods))
			{
				// close(inet_fd);
				return NULL;
			}
			gettimeofday(&end,NULL);
			time_use=(end.tv_sec-start.tv_sec)*1000+(end.tv_usec-start.tv_usec)/1000;//微秒
   			logDebug((*(info->log)), "socks5_auth function need  %.6f ms seq=%d\n",time_use, seq);

			gettimeofday(&start,NULL); //gettimeofday(&start,&tz);结果一样
			int command = socks5_command(net_fd);
			gettimeofday(&end,NULL); //gettimeofday(&start,&tz);结果一样
			time_use=(end.tv_sec-start.tv_sec)*1000+(end.tv_usec-start.tv_usec)/1000;//微秒
   			logDebug((*(info->log)), "socks5_command function need  %.6f ms seq=%d\n",time_use, seq);

			// log_message("command11=%d", command);
			if (command == (int)IP) 
			{
				// log_message("command11111=%d", command);
				gettimeofday(&start,NULL); //gettimeofday(&start,&tz);结果一样
				char *ip = socks_ip_read(net_fd);
				gettimeofday(&end,NULL); //gettimeofday(&start,&tz);结果一样
				time_use=(end.tv_sec-start.tv_sec)*1000+(end.tv_usec-start.tv_usec)/1000;//微秒
   				logDebug((*(info->log)), "socks_ip_read function need  %.6f ms seq=%d\n",time_use, seq);

				// log_message("ip=%s", ip);
				gettimeofday(&start,NULL); //gettimeofday(&start,&tz);结果一样
				unsigned short int p = socks_read_port(net_fd);
				gettimeofday(&end,NULL); //gettimeofday(&start,&tz);结果一样
				time_use=(end.tv_sec-start.tv_sec)*1000+(end.tv_usec-start.tv_usec)/1000;//微秒
   				logDebug((*(info->log)), "socks_read_port function need  %.6f ms seq=%d\n",time_use, seq);


				gettimeofday(&start,NULL); //gettimeofday(&start,&tz);结果一样
				inet_fd = app_connect(IP, (void *)ip, ntohs(p), (*(info->log)));
				if (inet_fd == -1) 
				{

					// app_thread_exit(1, net_fd);
					close(net_fd);
					gettimeofday(&end,NULL); //gettimeofday(&start,&tz);结果一样
					
					time_use=(end.tv_sec-start.tv_sec)*1000+(end.tv_usec-start.tv_usec)/1000;//微秒
   					logDebug((*(info->log)), "app_connect timeout  %.6f ms seq=%d\n",time_use, seq);
					// close(inet_fd);
					return NULL;
				}

				gettimeofday(&end,NULL); //gettimeofday(&start,&tz);结果一样
				time_use=(end.tv_sec-start.tv_sec)*1000+(end.tv_usec-start.tv_usec)/1000;//微秒
   				logDebug((*(info->log)), "app_connect function need  %.6f ms seq=%d\n",time_use, seq);

				gettimeofday(&start,NULL); //gettimeofday(&start,&tz);结果一样
				socks5_ip_send_response(net_fd, ip, p);
				gettimeofday(&end,NULL); //gettimeofday(&start,&tz);结果一样
				time_use=(end.tv_sec-start.tv_sec)*1000+(end.tv_usec-start.tv_usec)/1000;//微秒
   				logDebug((*(info->log)), "socks5_ip_send_response function need  %.6f ms seq=%d\n",time_use, seq);
				free(ip);
				break;
			} 
			else if (command == (int)DOMAIN) 
			{
				// log_message("command33=%d", command);
				unsigned char size;
				char *address = socks5_domain_read(net_fd, &size);
				unsigned short int p = socks_read_port(net_fd);

				inet_fd = app_connect(DOMAIN, (void *)address, ntohs(p), (*(info->log)));
				if (inet_fd == -1) {
					// app_thread_exit(1, net_fd);
					close(net_fd);
					return NULL;
				}
				socks5_domain_send_response(net_fd, address, size, p);
				free(address);
				break;
			} 
			else 
			{
				// log_message("command44=%d", command);
				// app_thread_exit(1, net_fd);
				close(net_fd);
				return NULL;
			}
		}
		case VERSION4: 
		{
			if (methods == 1) 
			{
				char ident[255];
				unsigned short int p = socks_read_port(net_fd);
				char *ip = socks_ip_read(net_fd);
				socks4_read_nstring(net_fd, ident, sizeof(ident));

				if (socks4_is_4a(ip)) 
				{
					char domain[255];
					socks4_read_nstring(net_fd, domain, sizeof(domain));
					logDebug((*(info->log)), "Socks4A: ident:%s; domain:%s;", ident, domain);
					inet_fd = app_connect(DOMAIN, (void *)domain, ntohs(p), (*(info->log)));
				} 
				else 
				{
					logDebug((*(info->log)), "Socks4: connect by ip & port");
					inet_fd = app_connect(IP, (void *)ip, ntohs(p), (*(info->log)));
				}

				if (inet_fd != -1) 
				{
					socks4_send_response(net_fd, 0x5a);
				}
				else 
				{
					socks4_send_response(net_fd, 0x5b);
					free(ip);
					// app_thread_exit(1, net_fd);
					close(net_fd);
					return NULL;
				}

				free(ip);
            } 
			else 
			{
                logDebug((*(info->log)), "Unsupported mode");
            }
			break;
		}
	}


	app_socket_pipe(inet_fd, net_fd, (*(info->log)), seq);
	close(inet_fd);
	// app_thread_exit(0, net_fd);
	close(net_fd);
	delete (int *)fd;
    return NULL;
}

int app_loop(CLog &log)
{
	CLog procclientmsg("procclientmsg");
	if(procclientmsg.init(CLOG_DEBUG) < 0)
	{
		fprintf(stderr, "init log faild.\n");
	}
	ThreadPool pool(100);  // 弄4个线程
	int sock_fd, net_fd;
	int optval = 1;
	struct sockaddr_in local, remote;
	socklen_t remotelen;
	if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
	{
		logError(log, "socket()");
		exit(1);
	}

	if (setsockopt
	    (sock_fd, SOL_SOCKET, SO_REUSEADDR, (char *)&optval,sizeof(optval)) < 0) 
	{
		logError(log, "setsockopt()");
		
		exit(1);
	}

	memset(&local, 0, sizeof(local));
	local.sin_family = AF_INET;
	local.sin_addr.s_addr = htonl(INADDR_ANY);
	local.sin_port = htons(port);

	if (bind(sock_fd, (struct sockaddr *)&local, sizeof(local)) < 0) 
	{
		logError(log, "bind()");
		exit(1);
	}

	if (listen(sock_fd, 25) < 0) 
	{
		logError(log, "listen()");
		exit(1);
	}

	remotelen = sizeof(remote);
	memset(&remote, 0, sizeof(remote));

	logDebug(log, "Listening port %d...", port);

	pthread_t worker;
	int curcnt = 1;
	while (1) 
	{
		if ((net_fd =accept(sock_fd, (struct sockaddr *)&remote,&remotelen)) < 0) 
		{
			logError(log, "accept()");
			
			exit(1);
		}
		
        int one = 1;
		logDebug(log, "You got a connection from host[%s] port[%d] fd[%d]",
			inet_ntoa(remote.sin_addr), ntohs(remote.sin_port), net_fd);
		
        setsockopt(sock_fd, SOL_TCP, TCP_NODELAY, &one, sizeof(one));

		int *arg = new int(net_fd);
		StSockInfo *info = new StSockInfo;
		info->sock = net_fd;
		info->seq = curcnt++;
		info->log = &procclientmsg;
        // pool.addTask(app_thread_process, arg);
		pool.addTask(app_thread_process, info);

		// if (pthread_create
		//     (&worker, NULL, &app_thread_process,
		//      (void *)&net_fd) == 0) 
		// {
		// 	pthread_detach(worker);
		// }
		// else 
		// {
		// 	log_message("pthread_create()");
		// }
	}
}

void daemonize()
{
	pid_t pid;
	int x;

	pid = fork();

	if (pid < 0) 
	{
		exit(EXIT_FAILURE);
	}

	if (pid > 0) 
	{
		exit(EXIT_SUCCESS);
	}

	if (setsid() < 0) 
	{
		exit(EXIT_FAILURE);
	}

	signal(SIGCHLD, SIG_IGN);
	signal(SIGHUP, SIG_IGN);

	pid = fork();

	if (pid < 0) 
	{
		exit(EXIT_FAILURE);
	}

	if (pid > 0) 
	{
		exit(EXIT_SUCCESS);
	}

	umask(0);
	chdir("/");

	for (x = sysconf(_SC_OPEN_MAX); x >= 0; x--) 
	{
		close(x);
	}
}

void usage(char *app, CLog &log)
{
	logDebug(log, "USAGE: %s [-h][-n PORT][-a AUTHTYPE][-u USERNAME][-p PASSWORD][-l LOGFILE]\n", app);
	logDebug(log, "AUTHTYPE: 0 for NOAUTH, 2 for USERPASS\n");
	logDebug(log, "By default: port is 1080, authtype is no auth, logfile is stdout\n");
	exit(1);
}

int Getdx(const string str)
{
	 std::vector<string>value;
    char* s_input = (char*)str.c_str();
	char* split = " ";// 以分号为分隔符拆分字符串
	char* ptr = NULL;
	char* p = strtok_r(s_input, split, &ptr);
	string strres = "";
	while (p != NULL)
	{
		// value.push_back(p);
		// cout << "p=" << p << endl;
		strres = p;
		break;
		// p = strtok_r(NULL, split, &ptr);
	}

	split = "/";
	p = strtok_r(s_input, split, &ptr);
	while (p != NULL)
	{
		value.push_back(p);
		
		// break;
		p = strtok_r(NULL, split, &ptr);
	}


	vector<string>::reverse_iterator it = value.rbegin();
	// cout << "p=" << *it << endl;
	return atoi((*it).c_str());
}

bool compareByNic(StNicInfo nic1,StNicInfo nic2)
{
	if (nic1.strnic.length() == nic2.strnic.length())
    	return nic1.strnic < nic2.strnic;
	else if (nic1.strnic.length() < nic2.strnic.length())
	{
		return true;
	}
	else
	{
		return false;
	}
}

int GetModemInfo(CLog &log)
{
	FILE *fp1 = NULL;
	char buf[256];
	char cmd[256];
	// logDebug(log, "GetModemInfo: func begn");
	snprintf(cmd, sizeof(cmd), "mmcli -L");
	if ((fp1 = popen(cmd, "r")) == NULL)
	{
		logError(log, "popen fail\n");
		return -1;
	}

	vector <StNicInfo> vecTmp;
	for (auto data:vecstr)
	{
		vecTmp.push_back(data);
	}

	// std::vector<string> copyInit(vecstr);
	vecstr.clear();
	std::vector<std::string> strResult;
	while (fgets(buf, 256, fp1) != NULL)
	{
		char *pos = strstr(buf, "\r");
		if (pos)
			*pos = '\0';
		pos = strstr(buf, "\n");
		if (pos)
			*pos = '\0';
		
		string str = buf;
		str.erase(str.begin(), std::find_if(str.begin(), str.end(),
		std::not1(std::ptr_fun(::isspace))));
		
		int idx = Getdx(str);
		// printf("main: str=[%s] idx=%d\n", str.c_str(), idx);
		char buf[2560];
		
		FILE *fp2 = NULL;
		snprintf(cmd, 256, "mmcli -m %d", idx);
		if ((fp2 = popen(cmd, "r")) == NULL)
		{
			logError(log, "popen fail\n");
		}

		// log_message("GetModemInfo cmd=%s\n", cmd);

		// cout << "cmd=" << cmd << endl;
		while (fgets(buf, 2560, fp2) != NULL)
		{
			char *pos = strstr(buf, "\r");
			if (pos)
				*pos = '\0';

			pos = strstr(buf, "\n");
			if (pos)
				*pos = '\0';
		
			str = buf;
			str.erase(str.begin(), std::find_if(str.begin(), str.end(),
			std::not1(std::ptr_fun(::isspace))));
			
			std::vector<string> value;
			char* s_input = (char*)str.c_str();
			char* split = ",";// 以分号为分隔符拆分字符串
			char* ptr = NULL;
			char* p = strtok_r(s_input, split, &ptr);
			string strres = "";
			while (p != NULL)
			{
				value.push_back(p);
				
				p = strtok_r(NULL, split, &ptr);
			}

			vector<string>::reverse_iterator it = value.rbegin();
			split = " ";// 以分号为分隔符拆分字符串
			ptr = NULL;
			
			s_input = (char*)(*it).c_str();
			p = strtok_r(s_input, split, &ptr);
			strres = "";
			while (p != NULL)
			{
				strres = p;
				break;
			}
			
			if (NULL != strstr(strres.c_str(), "wwan"))
			{
				// logDebug(log, "str=%s idx=%d", strres.c_str(), idx);
				FILE *fp3 = NULL;
				
				snprintf(cmd, sizeof(cmd), "ifconfig |grep %s",strres.c_str());
				if ((fp3 = popen(cmd, "r")) != NULL)
				{
					
					// logDebug(log, "popen fail\n");
					// continue;
					// return -1;
					if (fgets(buf, 256, fp3) == NULL)
					{
						snprintf(cmd, sizeof(cmd), "ifconfig %s up", strres.c_str());
						int ret = system(cmd);
						logDebug(log, "cmd=%s ret=%d", cmd, ret);
						if (0 != ret)
						{
							logError(log, "Excute shell cmd[%s] failed, return:%d.", cmd, ret>>8);
							// return 0;
						}
						else
						{
							StNicInfo stNicInfo(strres, idx);
							vecstr.push_back(stNicInfo);
						}
					}
					else
					{
						StNicInfo stNicInfo(strres, idx);
						vecstr.push_back(stNicInfo);
					}
				
					pclose(fp3);
				}
			}
		}

		pclose(fp2);
	}

	pclose(fp1);
	for (auto &data:vecstr)
	{
		snprintf(cmd, sizeof(cmd), "ifconfig %s|grep inet|grep -v 127.0.0.1|grep -v inet6|awk '{print $2}'|tr -d \"addr:\"",
		data.strnic.c_str());
		if ((fp1 = popen(cmd, "r")) == NULL)
		{
			logError(log, "popen fail\n");
			continue;
			// return -1;
		}
		if (fgets(buf, 256, fp1) != NULL)
		{
			// logDebug(log, "%s network restart succeed", data.strnic.c_str());
			// pthread_mutex_lock(&niclock);
			data.enable();
			// pthread_mutex_unlock(&niclock);
		}

		pclose(fp1);
	}

	for (auto data:vecTmp)
	{
		for (auto &inf:vecstr)
		{
			if (inf.strnic == data.strnic)
			{
				// inf.iscanused = data.iscanused;
				inf.currentcnt = data.currentcnt;
				inf.idx = data.idx;
				break;
			}
		}
	}

	//自定义排序，按身高降序，身高相同时则按名字升序排列
    sort(vecstr.begin(),vecstr.end(),compareByNic);

	// for (auto &data:vecstr)
	// {
	// 	logDebug(log, "str=%s idx=%d iscanused=%d currentcnt=%d", data.strnic.c_str(), data.idx, data.iscanused,
	// 		data.currentcnt);
	// }

	return 0;
}

int main(int argc, char *argv[])
{
	int ret;
	CLog log("server");
	if(log.init(CLOG_DEBUG) < 0)
	{
		fprintf(stderr, "init log faild.\n");
	}

	

	// int tmpdata = 256;
	// logDebug(log, "ret=%d", tmpdata>>8);
	// return 0;
	GetModemInfo(log);
	
	  //自定义排序，按身高降序，身高相同时则按名字升序排列
    sort(vecstr.begin(),vecstr.end(),compareByNic);

	for (auto &data:vecstr)
	{
		logDebug(log, "str=%s idx=%d iscanused=%d currentcnt=%d", data.strnic.c_str(), data.idx, data.iscanused,
			data.currentcnt);
	}
	
	log_file = stdout;
	auth_type = NOAUTH;
	arg_username = "user";
	arg_password = "pass";
	
	pthread_mutex_init(&niclock, NULL);

	signal(SIGPIPE, SIG_IGN);
	
	while ((ret = getopt(argc, argv, "n:u:p:l:a:hd")) != -1) 
	{
		switch (ret) 
		{
		case 'd':{
				daemon_mode = 1;
				daemonize();
				break;
			}
		case 'n':{
				port = atoi(optarg) & 0xffff;
				break;
			}
		case 'u':{
				arg_username = strdup(optarg);
				break;
			}
		case 'p':{
				arg_password = strdup(optarg);
				break;
			}
		case 'l':{
				freopen(optarg, "wa", log_file);
				break;
			}
		case 'a':{
				auth_type = atoi(optarg);
				break;
			}
		case 'h':
		default:
			usage(argv[0], log);
		}
	}
	// log_message("Starting with authtype 11 %X", auth_type);
	if (auth_type != NOAUTH) 
	{
		logError(log, "Username is %s, password is %s", arg_username,
			    arg_password);
	}

	// std::thread t1(executethd);
	std::thread t2(checknicinfo);
	curidx = 0;
	app_loop(log);
	return 0;
}

