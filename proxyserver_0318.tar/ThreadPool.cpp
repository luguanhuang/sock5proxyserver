#include "ThreadPool.h"
#include <errno.h>
#include <stdio.h>
#include <time.h>
#include <iostream>
using namespace std;

void *workerThread(void *arg);

ThreadPool::ThreadPool(int threadsLimit) : _valid(true), _count(0), _idle(0), _quit(0), _threadsLimit(threadsLimit)
{
    _valid = true;
	// 接下来初始化一系列变量，失败就false
    if (pthread_mutex_init(&_mutex, nullptr) != 0) 
    {
        perror("pthread_mutex_init");
        _valid = false;
    }

    if (pthread_cond_init(&_cond, nullptr) != 0) 
    {
        perror("pthread_cond_init");
        _valid = false;
    }

    if (pthread_attr_init(&_attr) != 0) 
    {
        perror("pthread_attr_init");
        _valid = false;
    }

    if (pthread_attr_setdetachstate(&_attr, PTHREAD_CREATE_DETACHED) != 0) 
    {
        perror("pthread_attr_setdetachstate");
        _valid = false;
    }

    pthread_t tid;
    for (int i=0; i<_threadsLimit; i++)
    {
         pthread_create(&tid, &_attr, workerThread, this); 
    }
}

ThreadPool::~ThreadPool()
{
    if (_quit)
        return;

    pthread_mutex_lock(&_mutex);
    _quit = 1;

    if (_count > 0) 
    {
        if (_idle > 0) 
        {
            printf("idle[%d] count[%d]\n", _idle, _count);

            // 唤醒休眠的线程
            pthread_cond_broadcast(&_cond);
        }

        while (_count) 
        {
            printf("count[%d] idle[%d]\n", _count, _idle);

            // 最后一个线程退出的时候会发送信号
            pthread_cond_wait(&_cond, &_mutex);
        }
    }

    pthread_mutex_unlock(&_mutex);

    if ((pthread_mutex_destroy(&_mutex)) != 0) 
    {
        perror("pthread_mutex_destroy");
    }

    if ((pthread_cond_destroy(&_cond)) != 0) 
    {
        perror("pthread_cond_destroy");
    }

    if ((pthread_attr_destroy(&_attr)) != 0) 
    {
        perror("pthread_cond_destroy");
    }
}

// 工作线程
void *workerThread(void *arg)
{
    // printf("[%lu] --> Start\n", pthread_self());

    // struct timespec abstime;
    // int timeout = 0;

    ThreadPool *pool = (ThreadPool *)arg;
    // 循环
    // for (;;) 
    // {
    //     pthread_mutex_lock(&pool->_mutex);

    //     pool->_idle++;  // 新启动线程啥也没干，空闲线程+1
    //     //  printf("[%lu] --> Start11 _count=%d\n", pthread_self(), pool->_count);
    //     //等待队列有任务到来 或者 收到线程池销毁通知
    //     while (pool->_tasks.empty() && !pool->_quit) 
    //     {
    //         // printf("[%lu] --> Waiting\n", pthread_self());

    //         clock_gettime(CLOCK_REALTIME, &abstime);
    //         abstime.tv_sec += 1;
	// 		// 等他2秒钟，看看又没人叫我干活
    //         if (pthread_cond_timedwait(&pool->_cond, &pool->_mutex, &abstime) == ETIMEDOUT) 
    //         {
    //             // printf("[%lu] --> Wait timeout\n", pthread_self());
    //             timeout = 1;  // 没活
    //             break;
    //         }
    //     }
    //     // printf("[%lu] --> Start22 _count=%d\n", pthread_self(), pool->_count);
    //     pool->_idle--;  // 空闲线程-1，干点活或者结束本次循环
    //     // 有活了，干活干活
    //     if (!pool->_tasks.empty()) 
    //     {
    //         //  printf("[%lu] --> Start33 _count=%d\n", pthread_self(), pool->_count);
    //         // printf("[%lu] --> Running a task\n", pthread_self());

    //         ThreadPool::ThreadTask task = pool->_tasks.front();
    //         pool->_tasks.pop();
    //         // 解锁让其他线程运行
    //         pthread_mutex_unlock(&pool->_mutex);

    //         // 取出一个任务，开始干活
    //         task.task(task.arg);

    //         // 干完了，新加锁进行下一步
    //         pthread_mutex_lock(&pool->_mutex);
    //     }
    //     //  printf("[%lu] --> Start44 _count=%d\n", pthread_self(), pool->_count);
	// 	// 程序退出了，进入析构函数的时候
    //     if (pool->_quit && pool->_tasks.empty()) 
    //     {
    //         //  printf("[%lu] --> Start55 _count=%d\n", pthread_self(), pool->_count);
    //         // printf("[%lu] --> _quit && _tasks.empty()\n", pthread_self());
    //         pool->_count--; // 结束本线程

    //         //若线程池中没有线程，通知等待线程（主线程）全部任务已经完成
    //         if (pool->_count == 0) 
    //         {
    //             pthread_cond_signal(&pool->_cond);
    //         }

    //         pthread_mutex_unlock(&pool->_mutex);
    //         break;
    //     }
		
    //     //  printf("[%lu] --> Start66 _count=%d\n", pthread_self(), pool->_count);
	// 	// 超时没等来活，先退了 (也可以不退的)
    //     if (timeout == 1) 
    //     {
    //         #if 1   //lgh
    //         pool->_count--;  //当前工作的线程数-1
    //         pthread_mutex_unlock(&pool->_mutex);
    //         //  printf("[%lu] --> Start77 _count=%d\n", pthread_self(), pool->_count);
    //         break;
    //         #endif
    //     }

    //     //  printf("[%lu] --> Start88 _count=%d\n", pthread_self(), pool->_count);

    //     pthread_mutex_unlock(&pool->_mutex);
    // }
    // cout << "workerThread func begin" << endl;
    for (;;) 
    {
        pthread_mutex_lock(&pool->_mutex);

        // pool->_idle++;  // 新启动线程啥也没干，空闲线程+1
        //  printf("[%lu] --> Start11 _count=%d\n", pthread_self(), pool->_count);
        //等待队列有任务到来 或者 收到线程池销毁通知
        while (pool->_tasks.empty()) 
        {
            // printf("[%lu] --> Waiting\n", pthread_self());
            // clock_gettime(CLOCK_REALTIME, &abstime);
            // abstime.tv_sec += 1;
			// 等他2秒钟，看看又没人叫我干活
            pthread_cond_wait(&pool->_cond, &pool->_mutex);
        }

        ThreadPool::ThreadTask task = pool->_tasks.front();
        pool->_tasks.pop();
         pthread_mutex_unlock(&pool->_mutex);
          task.task(task.arg);
        // printf("[%lu] --> Start22 _count=%d\n", pthread_self(), pool->_count);
        // pool->_idle--;  // 空闲线程-1，干点活或者结束本次循环
        // 有活了，干活干活
    }

    //  printf("[%lu] --> Start99 _count=%d\n", pthread_self(), pool->_count);
    // printf("[%lu] --> Exit\n", pthread_self());
    return nullptr;
}

void ThreadPool::addTask(function task, void *arg)
{
    if (!_valid || task == nullptr)
        return;

    // pthread_mutex_lock(&_mutex);

    // ThreadTask t(task, arg);
    // _tasks.emplace(t);

    // // printf("addTask tasks111[%d] count[%d] idle[%d] _idle=%d\n", (int)_tasks.size(), _count, _idle,
	// // 	_idle);

    // if (_idle > 0) 
    // {
    //     // 有正在睡觉的线程的话，叫醒一个
    //     //   printf("addTask tasks222[%d] count[%d] idle[%d] _idle=%d\n", (int)_tasks.size(), _count, _idle,
	// 	// _idle);
    //     pthread_cond_signal(&_cond);
    // } 
    // else if (_count < _threadsLimit) 
    // {
    // 	//   printf("addTask tasks333[%d] count[%d] idle[%d] _idle=%d\n", (int)_tasks.size(), _count, _idle,
	// 	// _idle);
    //     pthread_t tid;
	// 	// 启动一个线程，把当前实例指针作为参数传递过去，主要是要用到此类中的那些变量
    //     pthread_create(&tid, &_attr, workerThread, this); 
    //     _count++; // 线程数+1
    // }

    // pthread_mutex_unlock(&_mutex);

    pthread_mutex_lock(&_mutex);
    ThreadTask t(task, arg);
    _tasks.emplace(t);
    pthread_mutex_unlock(&_mutex);
    pthread_cond_signal(&_cond);
    // printf("addTask tasks111[%d] count[%d] idle[%d] _idle=%d\n", (int)_tasks.size(), _count, _idle,
	// 	_idle);
}
